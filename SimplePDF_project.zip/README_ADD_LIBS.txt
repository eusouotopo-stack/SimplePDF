If Gradle can't download iText, download iTextG 5.5.10 jar and place it in 'libs/' before building.
