package com.simplepdf.creator;

// Utility placeholder - expand later (e.g., merge PDFs, add metadata).
public class PDFUtils {
    // Intentionally left simple for first version.
}
