SimplePDF - Small starter Android project (Java)
===============================================

What's inside
--------------
- MainActivity.java
- CreatePDFActivity.java
- PDFUtils.java
- activity_main.xml
- activity_create_pdf.xml
- AndroidManifest.xml
- build.gradle
- proguard-rules.pro

Notes
-----
1) This project is intentionally simple and uses iText (com.itextpdf:itextg:5.5.10) to generate PDFs.
   If your build environment can't fetch dependencies, add an iText jar into a `libs/` folder:
   - Download iText G (5.5.10) and place the JAR in libs/ then modify build.gradle to include it as a file dependency.

2) Permission: the app requests READ/WRITE external storage. On Android 10+ consider using MediaStore or scoped storage changes.

3) To compile:
   - Use AIDE on Android, or a CI/CD service that builds Android projects from a GitHub repo.

4) This initial version does NOT include Google Play Billing or upload limits. Those will be added after you confirm the APK builds.

How to use
----------
- Open MainActivity, press Create PDF
- Type text, press Save as PDF
- PDF is stored in the device Downloads folder

Next steps
----------
- Add daily limit logic (SharedPreferences)
- Add upload (ImagePicker / FilePicker)
- Integrate Google Play Billing for subscription
