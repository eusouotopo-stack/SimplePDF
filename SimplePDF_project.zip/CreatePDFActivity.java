package com.simplepdf.creator;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.io.File;

public class CreatePDFActivity extends Activity {

    EditText inputText;
    Button savePDF;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_pdf);

        inputText = findViewById(R.id.inputText);
        savePDF = findViewById(R.id.savePDF);

        savePDF.setOnClickListener(v -> createPDF());
    }

    private void createPDF() {
        try {
            String folderPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath();
            File folder = new File(folderPath);
            if (!folder.exists()) {
                folder.mkdirs();
            }

            Document document = new Document();
            String filePath = folderPath + "/SimplePDF_" + System.currentTimeMillis() + ".pdf";
            PdfWriter.getInstance(document, new FileOutputStream(filePath));

            document.open();
            document.add(new Paragraph(inputText.getText().toString()));
            document.close();

            Toast.makeText(this, "Saved in: " + filePath, Toast.LENGTH_LONG).show();

        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }
}
