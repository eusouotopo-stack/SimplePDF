package com.simplepdf.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;

public class CreatePDFActivity extends Activity {
    EditText editText;
    Button btnSaveText, btnPickImage, btnSaveImages;
    ArrayList<Uri> imageUris = new ArrayList<>();
    SharedPreferences prefs;
    final int REQ_PICK = 1234;
    final int LIMIT = 3;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_create_pdf);

        prefs = getSharedPreferences("simplepdf_prefs", MODE_PRIVATE);

        editText = findViewById(R.id.editText);
        btnSaveText = findViewById(R.id.btnSaveText);
        btnPickImage = findViewById(R.id.btnPickImage);
        btnSaveImages = findViewById(R.id.btnSaveImages);

        btnSaveText.setOnClickListener(v -> {
            if (!canUseToday()) { Toast.makeText(this, "Daily limit reached", Toast.LENGTH_SHORT).show(); return; }
            String text = editText.getText().toString();
            if (text.isEmpty()) { Toast.makeText(this, "Type some text", Toast.LENGTH_SHORT).show(); return; }
            if (createPdfFromText(text)) {
                increaseCount();
            }
        });

        btnPickImage.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            startActivityForResult(Intent.createChooser(intent, "Select images"), REQ_PICK);
        });

        btnSaveImages.setOnClickListener(v -> {
            if (imageUris.size()==0) { Toast.makeText(this, "Pick at least one image", Toast.LENGTH_SHORT).show(); return; }
            if (!canUseToday()) { Toast.makeText(this, "Daily limit reached", Toast.LENGTH_SHORT).show(); return; }
            if (createPdfFromImages(imageUris)) {
                increaseCount();
                imageUris.clear();
            }
        });
    }

    boolean canUseToday() {
        boolean isPremium = prefs.getBoolean("is_premium", false);
        if (isPremium) return true;
        String today = String.valueOf(System.currentTimeMillis()/86400000L);
        String last = prefs.getString("day", "0");
        int count = prefs.getInt("count", 0);
        if (!today.equals(last)) {
            prefs.edit().putString("day", today).putInt("count", 0).apply();
            return true;
        }
        return count < LIMIT;
    }

    void increaseCount() {
        int c = prefs.getInt("count", 0);
        prefs.edit().putInt("count", c+1).apply();
    }

    boolean createPdfFromText(String text) {
        try {
            String folderPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath();
            File folder = new File(folderPath);
            if (!folder.exists()) folder.mkdirs();
            String filePath = folderPath + "/SimplePDF_text_" + System.currentTimeMillis() + ".pdf";
            Document doc = new Document();
            PdfWriter.getInstance(doc, new FileOutputStream(filePath));
            doc.open();
            doc.add(new Paragraph(text));
            doc.close();
            Toast.makeText(this, "Saved: " + filePath, Toast.LENGTH_LONG).show();
            saveHistory(filePath);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error creating PDF", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    boolean createPdfFromImages(ArrayList<Uri> uris) {
        try {
            String folderPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath();
            File folder = new File(folderPath);
            if (!folder.exists()) folder.mkdirs();
            String filePath = folderPath + "/SimplePDF_images_" + System.currentTimeMillis() + ".pdf";
            Document doc = new Document();
            PdfWriter.getInstance(doc, new FileOutputStream(filePath));
            doc.open();
            for (Uri u : uris) {
                InputStream is = getContentResolver().openInputStream(u);
                Image img = Image.getInstance(org.apache.commons.io.IOUtils.toByteArray(is));
                img.scaleToFit(500, 700);
                doc.add(img);
            }
            doc.close();
            Toast.makeText(this, "Saved: " + filePath, Toast.LENGTH_LONG).show();
            saveHistory(filePath);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error creating PDF from images", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    void saveHistory(String path) {
        String existing = prefs.getString("history", "");
        String updated = existing.isEmpty() ? path : existing + "|" + path;
        prefs.edit().putString("history", updated).apply();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==REQ_PICK && resultCode==RESULT_OK) {
            imageUris.clear();
            if (data.getClipData()!=null) {
                int c = data.getClipData().getItemCount();
                for (int i=0;i<c;i++) {
                    imageUris.add(data.getClipData().getItemAt(i).getUri());
                }
            } else if (data.getData()!=null) {
                imageUris.add(data.getData());
            }
            Toast.makeText(this, imageUris.size() + " images selected", Toast.LENGTH_SHORT).show();
        }
    }
}
