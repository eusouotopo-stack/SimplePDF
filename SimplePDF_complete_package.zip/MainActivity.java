package com.simplepdf.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnCreate = findViewById(R.id.btnCreate);
        Button btnHistory = findViewById(R.id.btnHistory);
        Button btnPremium = findViewById(R.id.btnPremium);
        TextView tvInfo = findViewById(R.id.tvInfo);

        btnCreate.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, CreatePDFActivity.class)));
        btnHistory.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, HistoryActivity.class)));
        btnPremium.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, PremiumActivity.class)));
    }
}
