package com.simplepdf.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class PremiumActivity extends Activity {
    SharedPreferences prefs;
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_premium);
        prefs = getSharedPreferences("simplepdf_prefs", MODE_PRIVATE);
        TextView tv = findViewById(R.id.tvPremium);
        Button btnBuy = findViewById(R.id.btnBuy);
        Button btnRestore = findViewById(R.id.btnRestore);

        tv.setText("Unlock unlimited PDFs: 3-day trial available. Monthly $1.69 / Annual $5.69");

        btnBuy.setOnClickListener(v -> {
            // Simulate purchase: set flag locally
            prefs.edit().putBoolean("is_premium", true).apply();
            Toast.makeText(this, "Premium activated (simulated)", Toast.LENGTH_SHORT).show();
            finish();
        });

        btnRestore.setOnClickListener(v -> {
            boolean p = prefs.getBoolean("is_premium", false);
            Toast.makeText(this, p ? "Premium active" : "No purchase found", Toast.LENGTH_SHORT).show();
        });
    }
}
