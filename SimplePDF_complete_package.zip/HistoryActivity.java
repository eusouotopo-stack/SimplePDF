package com.simplepdf.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

public class HistoryActivity extends Activity {
    ListView listView;
    SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_history);
        listView = findViewById(R.id.listHistory);
        prefs = getSharedPreferences("simplepdf_prefs", MODE_PRIVATE);
        refreshList();
        listView.setOnItemClickListener((parent, view, position, id) -> {
            String item = (String) parent.getItemAtPosition(position);
            File f = new File(item);
            if (f.exists()) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(Uri.fromFile(f), "application/pdf");
                intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                startActivity(intent);
            } else {
                Toast.makeText(this, "File not found", Toast.LENGTH_SHORT).show();
            }
        });
    }

    void refreshList() {
        String hist = prefs.getString("history", "");
        if (hist.isEmpty()) {
            listView.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<String>()));
            return;
        }
        ArrayList<String> items = new ArrayList<>(Arrays.asList(hist.split("\|")));
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        listView.setAdapter(ad);
    }
}
