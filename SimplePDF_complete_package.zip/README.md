SimplePDF — Complete starter package (all-in-one)
================================================

What is included:
- SplashActivity (simple splash)
- MainActivity (home UI)
- CreatePDFActivity (text + image PDF generation)
- HistoryActivity (list generated PDFs)
- PremiumActivity (simulate purchase; later integrate Google Play Billing)
- Daily limit: free users allowed 3 PDF generations/day (uploads/images)
- Uses iText (bundle jar expected in libs/)

How to build:
1) Place itextg-5.5.10.jar inside libs/ (or change build.gradle to fetch via maven)
2) Upload repository to GitHub
3) Use a CI/tool that builds Android apps from repo, or open in AIDE and compile
4) Test on device; grant storage permissions

Notes:
- Premium flow is simulated via a "Buy (simulate)" button that sets a local flag.
- Real Google Play Billing requires adding the Billing library and server/config steps.
